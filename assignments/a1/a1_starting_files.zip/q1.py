# q1.py

#
# Full Name:
# SFU Email:
#

# ... put your answer to question 1 here ...

# q4.py

#
# Full Name:
# SFU Email:
#

# ... put your answer to question 4 here ...
